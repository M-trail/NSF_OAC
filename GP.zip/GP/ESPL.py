import subprocess

# Replace 'script1.py', 'script2.py' with your script names
subprocess.run(["python", "ESPL_MODEL_CLEAN.py"])
subprocess.run(["python", "PUREML_MODEL.py"])
subprocess.run(["python", "main.py"])
subprocess.run(["python", "TESTING_EM.py"])
# Add more scripts as needed
