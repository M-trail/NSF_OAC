import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
import xlrd as xlrd
import pandas as pd

plt.rcParams['font.family'] = 'Times New Roman'
x = []
y = []
x_small_sample = []
y_small_sample = []
# Load data from Excel file
#Case 1
data = xlrd.open_workbook(r'C:\Users\user\PycharmProjects\Data\364.xls')
table = data.sheet_by_index(0)

for i in range(1, table.nrows):
    x_small_sample.append(table.cell_value(i, 11) * 12/
                          (table.cell_value(i, 12) * 5))
    y_small_sample.append(table.cell_value(i, 12))
data1 = xlrd.open_workbook(r'C:\Users\user\PycharmProjects\Data\365.xls')
table1 = data1.sheet_by_index(0)
for i in range(1, table1.nrows):
    x.append(table1.cell_value(i, 11) * 12 /
             (table1.cell_value(i, 12) * 5))
    y.append(table1.cell_value(i, 12))
data2 = xlrd.open_workbook(r'C:\Users\user\PycharmProjects\Data\366.xls')
table2 = data2.sheet_by_index(0)
for i in range(1, table2.nrows):
    x.append(table2.cell_value(i, 11) * 12 /
                          (table2.cell_value(i, 12) * 5))
    y.append(table2.cell_value(i, 12))
data3 = xlrd.open_workbook(r'C:\Users\user\PycharmProjects\Data\368.xls')
table3 = data3.sheet_by_index(0)
for i in range(1, table3.nrows):
    x.append(table3.cell_value(i, 9) * 12 /
             (table3.cell_value(i, 10) * 4))
    y.append(table3.cell_value(i, 10))
data4 = xlrd.open_workbook(r'C:\Users\user\PycharmProjects\Data\374.xls')
table4 = data4.sheet_by_index(0)
for i in range(1, table4.nrows):
    x_small_sample.append(table4.cell_value(i, 9) * 12 /
                  (table4.cell_value(i, 10) * 4))
    y_small_sample.append(table4.cell_value(i, 10))
#Case 2

data5 = xlrd.open_workbook(r'C:\Users\user\PycharmProjects\Data\375.xls')
table5 = data5.sheet_by_index(0)
for i in range(1, table5.nrows):
    x_small_sample.append(table5.cell_value(i, 11) * 12 /
             (table5.cell_value(i, 12) * 5))
    y_small_sample.append(table5.cell_value(i, 12))
data6 = xlrd.open_workbook(r'C:\Users\user\PycharmProjects\Data\377.xls')
table6 = data6.sheet_by_index(0)
for i in range(1, table6.nrows):
    x.append(table6.cell_value(i, 9) * 12 /
                          (table6.cell_value(i, 10) * 5))
    y.append(table6.cell_value(i, 10))
data7 = xlrd.open_workbook(r'C:\Users\user\PycharmProjects\Data\381.xls')
table7 = data7.sheet_by_index(0)
for i in range(1, table7.nrows):
    x.append( table7.cell_value(i, 9) * 12 /
              (table7.cell_value(i, 10) * 4))
    y.append(table7.cell_value(i, 10))
data8 = xlrd.open_workbook(r'C:\Users\user\PycharmProjects\Data\384.xls')
table8 = data8.sheet_by_index(0)
for i in range(1, table8.nrows):
    x.append(table8.cell_value(i, 11) * 12 /
             (table8.cell_value(i, 12) * 5))
    y.append(table8.cell_value(i, 12))
data9 = xlrd.open_workbook(r'C:\Users\user\PycharmProjects\Data\388.xls')
table9 = data9.sheet_by_index(0)
for i in range(1, table9.nrows):
    x.append(table9.cell_value(i, 9) * 12 /
             (table9.cell_value(i, 10) * 4))
    y.append(table9.cell_value(i, 10))
data10 = xlrd.open_workbook(r'C:\Users\user\PycharmProjects\Data\389.xls')
table10 = data10.sheet_by_index(0)
for i in range(1, table10.nrows):
    x.append(table10.cell_value(i, 9) * 12 /
             (table10.cell_value(i, 10) * 4))
    y.append(table10.cell_value(i, 10))
data11 = xlrd.open_workbook(r'C:\Users\user\PycharmProjects\Data\391.xls')
table11 = data11.sheet_by_index(0)
for i in range(1, table11.nrows):
    x.append(table11.cell_value(i, 11) * 12 /
             (table11.cell_value(i, 12) * 5))
    y.append(table11.cell_value(i, 12))

data12 = xlrd.open_workbook(r'C:\Users\user\PycharmProjects\Data\393.xls')
table12 = data12.sheet_by_index(0)
for i in range(1, table12.nrows):
    x_small_sample.append(table12.cell_value(i, 11) * 12 /
             (table12.cell_value(i, 12) * 5))
    y_small_sample.append(table12.cell_value(i, 12))

X = np.array(x).reshape(-1, 1)
Y = np.array(y).reshape(-1, 1)
X_small_sample = np.array(x_small_sample).reshape(-1, 1)
Y_small_sample = np.array(y_small_sample).reshape(-1, 1)

sorted_indices = np.argsort(X, axis=0).flatten()
sorted_indices = np.argsort(X_small_sample, axis=0).flatten()
X_sorted = X[sorted_indices]
Y_sorted = Y[sorted_indices]
X_small_sample_sorted = X_small_sample[sorted_indices]
Y_small_sample_sorted = Y_small_sample[sorted_indices]
X_sorted = np.concatenate((X_sorted, X_small_sample_sorted), axis=0)
Y_sorted = np.concatenate((Y_sorted, Y_small_sample_sorted), axis=0)

df1 = pd.read_csv('Leve1_noise.csv')
X_noisy_1 = df1['Density (Veh/mile)'].values
Y_noisy_1 = df1['Speed (Mph)'].values
X_noisy_1 = X_noisy_1.reshape(-1, 1)
Y_noisy_1 = Y_noisy_1.reshape(-1, 1)

df2 = pd.read_csv('Leve2_noise.csv')
X_noisy_2 = df2['Density (Veh/mile)'].values
Y_noisy_2 = df2['Speed (Mph)'].values
X_noisy_2 = X_noisy_2.reshape(-1, 1)
Y_noisy_2 = Y_noisy_2.reshape(-1, 1)

df3 = pd.read_csv('Leve3_noise.csv')
X_noisy_3 = df3['Density (Veh/mile)'].values
Y_noisy_3 = df3['Speed (Mph)'].values
X_noisy_3 = X_noisy_3.reshape(-1, 1)
Y_noisy_3 = Y_noisy_3.reshape(-1, 1)


x_test = []
y_test = []
#Case 1
data13 = xlrd.open_workbook(r'C:\Users\user\PycharmProjects\Data\369.xls')
table13 = data13.sheet_by_index(0)
for i in range(1, table13.nrows):
    x_test.append(table13.cell_value(i, 9) * 12 /
                  (table13.cell_value(i, 10) * 4))
    y_test.append(table13.cell_value(i, 10))
data14 = xlrd.open_workbook(r'C:\Users\user\PycharmProjects\Data\372.xls')
table14 = data14.sheet_by_index(0)
for i in range(1, table14.nrows):
    x_test.append( table14.cell_value(i, 11) * 12/
              (table14.cell_value(i, 12) * 5))
    y_test.append(table14.cell_value(i, 12))
#Case 2

data15 = xlrd.open_workbook(r'C:\Users\user\PycharmProjects\Data\379.xls')
table15 = data15.sheet_by_index(0)
for i in range(1, table15.nrows):
    x_test.append(table15.cell_value(i, 11) * 12 /
                  (table15.cell_value(i, 12) * 5))
    y_test.append(table15.cell_value(i, 12))
data16 = xlrd.open_workbook(r'C:\Users\user\PycharmProjects\Data\386.xls')
table16 = data16.sheet_by_index(0)
for i in range(1, table16.nrows):
    x_test.append(table16.cell_value(i, 11) * 12 /
                  (table16.cell_value(i, 12) * 5))
    y_test.append(table16.cell_value(i, 12))

X_test = np.array(x_test).reshape(-1, 1)
Y_test = np.array(y_test).reshape(-1, 1)

sorted_indices = np.argsort(X_test, axis=0).flatten()
X_test_sorted = X_test[sorted_indices]
Y_test_sorted = Y_test[sorted_indices]


interval_test = 0
for i in range(len(X_test_sorted) - 1):
    interval_test = interval_test + X_test_sorted[i + 1] - X_test_sorted[i]
interval_test = interval_test/(len(X_test_sorted) - 1)
#print(interval)
indices_to_remove = []

mark_test = X_test_sorted[0]
for i in range(len(X_test_sorted) - 1):
    if X_test_sorted[i + 1] - X_test_sorted[i] >= interval_test:
        mark_test = X_test_sorted[i + 1]
    else:
        indices_to_remove.append(i + 1)

def tf_safe_wrapper(func):
    def safe_func(X, *args, **kwargs):
        X = tf.convert_to_tensor(X, dtype=tf.float32)
        return func(X, *args, **kwargs)
    return safe_func

@tf_safe_wrapper
def greenshields(X):
    return 79.60308 * (1 - (X / 94.80128))

Y_pred = greenshields(X_test_sorted)

# Calculate the RMSE
rmse_greenshields = tf.sqrt(tf.reduce_mean(tf.square(Y_test_sorted - Y_pred)))

# Calculate the MAPE
mape_greenshields = tf.reduce_mean(tf.abs((Y_test_sorted - Y_pred) / Y_test_sorted)) * 100

print("Original Greenshields Model")
print(f"RMSE: {rmse_greenshields:.4f}")
print(f"MAPE: {mape_greenshields:.4f}%")


@tf_safe_wrapper
def Cheng(X):
    return 73.07741/(1 + (X/28.037798)** 5.1283793)**(2/5.1283793)

Y_pred = Cheng(X_test_sorted)

# Calculate the RMSE
rmse_Cheng = tf.sqrt(tf.reduce_mean(tf.square(Y_test_sorted - Y_pred)))

# Calculate the MAPE
mape_Cheng = tf.reduce_mean(tf.abs((Y_test_sorted - Y_pred) / Y_test_sorted)) * 100

print("Original Cheng Model")
print(f"RMSE: {rmse_Cheng:.4f}")
print(f"MAPE: {mape_Cheng:.4f}%")

@tf_safe_wrapper
def Wang(X):
    return 15.022836 + ((73.39373 - 15.022836)/((1 + tf.math.exp((X - 26.082657)/4.4776545)) ** 0.37584168))

Y_pred = Wang(X_test_sorted)

# Calculate the RMSE
rmse_Wang = tf.sqrt(tf.reduce_mean(tf.square(Y_test_sorted - Y_pred)))

# Calculate the MAPE
mape_Wang = tf.reduce_mean(tf.abs((Y_test_sorted - Y_pred) / Y_test_sorted)) * 100

print("Original Wang Model")
print(f"RMSE: {rmse_Wang:.4f}")
print(f"MAPE: {mape_Wang:.4f}%")

@tf_safe_wrapper
def MacNicholas(X):
    return 73.52686 * ((205.54465 ** 3.7189584 - X ** 3.7189584)/(205.54465 ** 3.7189584 + 501.67047 * X ** 3.7189584))

Y_pred = MacNicholas(X_test_sorted)

# Calculate the RMSE
rmse_MacNicholas = tf.sqrt(tf.reduce_mean(tf.square(Y_test_sorted - Y_pred)))

# Calculate the MAPE
mape_MacNicholas = tf.reduce_mean(tf.abs((Y_test_sorted - Y_pred) / Y_test_sorted)) * 100

print("Original MacNicholas Model")
print(f"RMSE: {rmse_MacNicholas:.4f}")
print(f"MAPE: {mape_MacNicholas:.4f}%")

@tf_safe_wrapper
def greenberg(X):
    return 14.339008 * tf.math.log(898.36926 / (X + 1e-8))

Y_pred = greenberg(X_test_sorted)

# Calculate the RMSE
rmse_greenberg = tf.sqrt(tf.reduce_mean(tf.square(Y_test_sorted - Y_pred)))

# Calculate the MAPE
mape_greenberg = tf.reduce_mean(tf.abs((Y_test_sorted - Y_pred) / Y_test_sorted)) * 100

print("Original Greenberg Model")
print(f"RMSE: {rmse_greenberg:.4f}")
print(f"MAPE: {mape_greenberg:.4f}%")

@tf_safe_wrapper
def underwood(X):
    return 79.72064 * tf.math.exp(-X/82.72381)

Y_pred = underwood(X_test_sorted)

# Calculate the RMSE
rmse_underwood = tf.sqrt(tf.reduce_mean(tf.square(Y_test_sorted - Y_pred)))

# Calculate the MAPE
mape_underwood = tf.reduce_mean(tf.abs((Y_test_sorted - Y_pred) / Y_test_sorted)) * 100

print("Original Underwood Model")
print(f"RMSE: {rmse_underwood:.4f}")
print(f"MAPE: {mape_underwood:.4f}%")

@tf_safe_wrapper
def newell(X):
    return 74.6732 * (1 - tf.math.exp(- (3033.976/74.6732)*(1/X - 1/545.3822)))

Y_pred = newell(X_test_sorted)

# Calculate the RMSE
rmse_newell = tf.sqrt(tf.reduce_mean(tf.square(Y_test_sorted - Y_pred)))

# Calculate the MAPE
mape_newell = tf.reduce_mean(tf.abs((Y_test_sorted - Y_pred) / Y_test_sorted)) * 100

print("Original Newell Model")
print(f"RMSE: {rmse_newell:.4f}")
print(f"MAPE: {mape_newell:.4f}%")

@tf_safe_wrapper
def pipes(X):
    safe_X = tf.minimum(X, 62.00584)  # Ensuring X does not go above 8.7896
    return 78.210915 * (1 - safe_X / 62.00584) ** 0.5185358

Y_pred = pipes(X_test_sorted)

# Calculate the RMSE
rmse_pipes = tf.sqrt(tf.reduce_mean(tf.square(Y_test_sorted - Y_pred)))

# Calculate the MAPE
mape_pipes = tf.reduce_mean(tf.abs((Y_test_sorted - Y_pred) / Y_test_sorted)) * 100

print("Original Pipes Model")
print(f"RMSE: {rmse_pipes:.4f}")
print(f"MAPE: {mape_pipes:.4f}%")

@tf_safe_wrapper
def drew(X):
    return 73.990906 * (1 - (X / 283.10898) ** 2.8559134) ** 194.68063

Y_pred = drew(X_test_sorted)

# Calculate the RMSE
rmse_drew = tf.sqrt(tf.reduce_mean(tf.square(Y_test_sorted - Y_pred)))

# Calculate the MAPE
mape_drew = tf.reduce_mean(tf.abs((Y_test_sorted - Y_pred) / Y_test_sorted)) * 100

print("Original Drew Model")
print(f"RMSE: {rmse_drew:.4f}")
print(f"MAPE: {mape_drew:.4f}%")


@tf_safe_wrapper
def papageorgiou(X):
    return 73.988914 * tf.math.exp(-(1/2.8577895) * (X/30.932423) ** 2.8577895)

Y_pred = papageorgiou(X_test_sorted)

# Calculate the RMSE
rmse_papageorgiou = tf.sqrt(tf.reduce_mean(tf.square(Y_test_sorted - Y_pred)))

# Calculate the MAPE
mape_papageorgiou = tf.reduce_mean(tf.abs((Y_test_sorted - Y_pred) / Y_test_sorted)) * 100

print("Original Papageorgiou Model")
print(f"RMSE: {rmse_papageorgiou:.4f}")
print(f"MAPE: {mape_papageorgiou:.4f}%")

@tf_safe_wrapper
def kerner_konhauser(X):
    return 75.93196 * (1/(1 + tf.math.exp(((X/153.38695)-0.25)/(0.06)) - 3.72 * 10 **(-6)))

Y_pred = kerner_konhauser(X_test_sorted)

# Calculate the RMSE
rmse_kerner_konhauser = tf.sqrt(tf.reduce_mean(tf.square(Y_test_sorted - Y_pred)))

# Calculate the MAPE
mape_kerner_konhauser = tf.reduce_mean(tf.abs((Y_test_sorted - Y_pred) / Y_test_sorted)) * 100

print("Original Kerner-konhauser Model")
print(f"RMSE: {rmse_kerner_konhauser:.4f}")
print(f"MAPE: {mape_kerner_konhauser:.4f}%")

@tf_safe_wrapper
def delcastillo_benitez(X):
    return 73.64347 * (1 - tf.math.exp((64.28888/73.64347)* (1 - 73.77305/X)))

Y_pred = delcastillo_benitez(X_test_sorted)

# Calculate the RMSE
rmse_delcastillo_benitez = tf.sqrt(tf.reduce_mean(tf.square(Y_test_sorted - Y_pred)))

# Calculate the MAPE
mape_delcastillo_benitez = tf.reduce_mean(tf.abs((Y_test_sorted - Y_pred) / Y_test_sorted)) * 100

print("Original delcastillo-benitez Model")
print(f"RMSE: {rmse_delcastillo_benitez:.4f}")
print(f"MAPE: {mape_delcastillo_benitez:.4f}%")

@tf_safe_wrapper
def jayakrishnan(X):
    return 67.73154 + (79.60208 - 67.73154) * (1 - X/22.729082)

Y_pred = jayakrishnan(X_test_sorted)

# Calculate the RMSE
rmse_jayakrishnan = tf.sqrt(tf.reduce_mean(tf.square(Y_test_sorted - Y_pred)))

# Calculate the MAPE
mape_jayakrishnan = tf.reduce_mean(tf.abs((Y_test_sorted - Y_pred) / Y_test_sorted)) * 100

print("Original Jayakrishnan Model")
print(f"RMSE: {rmse_jayakrishnan:.4f}")
print(f"MAPE: {mape_jayakrishnan:.4f}%")

@tf_safe_wrapper
def edie(X, breakpoint):
    condition = X <= breakpoint
    return tf.where(
        condition,
        86.19598 * tf.math.exp(-(X ) / 51.856693),
        18.114496 * tf.math.log(159.73201 / (X ))
    )

Y_pred = edie(X_test_sorted, 50)

# Calculate the RMSE
rmse_edie = tf.sqrt(tf.reduce_mean(tf.square(Y_test_sorted - Y_pred)))

# Calculate the MAPE
mape_edie = tf.reduce_mean(tf.abs((Y_test_sorted - Y_pred) / Y_test_sorted)) * 100

print("Original Edie Model")
print(f"RMSE: {rmse_edie:.4f}")
print(f"MAPE: {mape_edie:.4f}%")

@tf_safe_wrapper
def two_regime(X, breakpoint):
    condition = X <= breakpoint
    return tf.where(
        condition,
        82.95282 - 1.1018451 * (X),
        20.520544 - 0.12301712 * (X)
    )

Y_pred = two_regime(X_test_sorted, 65)

# Calculate the RMSE
rmse_two_regime = tf.sqrt(tf.reduce_mean(tf.square(Y_test_sorted - Y_pred)))

# Calculate the MAPE
mape_two_regime = tf.reduce_mean(tf.abs((Y_test_sorted - Y_pred) / Y_test_sorted)) * 100

print("Original two-regime Model")
print(f"RMSE: {rmse_two_regime:.4f}")
print(f"MAPE: {mape_two_regime :.4f}%")


def modified_greenberg(X, breakpoint):
    condition = X <= breakpoint
    return tf.where(
        condition,
        66.131805 + X * 0,
        22.09243 * X * tf.math.log(147.85953 / (X))
    )

Y_pred = modified_greenberg(X_test_sorted, 35)

# Calculate the RMSE
rmse_modified_greenberg = tf.sqrt(tf.reduce_mean(tf.square(Y_test_sorted - Y_pred)))

# Calculate the MAPE
mape_modified_greenberg = tf.reduce_mean(tf.abs((Y_test_sorted - Y_pred) / Y_test_sorted)) * 100

print("Original modified-greenberg Model")
print(f"RMSE: {rmse_modified_greenberg:.4f}")
print(f"MAPE: {mape_modified_greenberg:.4f}%")

@tf_safe_wrapper
def three_regime(X, breakpoint1, breakpoint2):
    condition1 = X <= breakpoint1
    condition2 = tf.logical_and(breakpoint1 < X, X <= breakpoint2)
    condition3 = X > breakpoint2

    result1 = 82.207214 - 1.0211389 * (X)
    result2 = 52.25136 - 0.5437932 * (X)
    result3 = 20.520544 - 0.12301712 * (X)

    return tf.where(condition1, result1, tf.where(condition2, result2, result3))

Y_pred = three_regime(X_test_sorted, 40, 65)

# Calculate the RMSE
rmse_three_regime = tf.sqrt(tf.reduce_mean(tf.square(Y_test_sorted - Y_pred)))

# Calculate the MAPE
mape_three_regime = tf.reduce_mean(tf.abs((Y_test_sorted - Y_pred) / Y_test_sorted)) * 100

print("Original three-regime Model")
print(f"RMSE: {rmse_three_regime:.4f}")
print(f"MAPE: {mape_three_regime:.4f}%")